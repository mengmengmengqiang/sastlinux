/**
	File Name: 3.c
	Author: zhy
	Created Time: 2017/02/28 - 14:53:26
*/
#include <stdio.h>
void hereis3() {
	printf("here is 3\n");
}
