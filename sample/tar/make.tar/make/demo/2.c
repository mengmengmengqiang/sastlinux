/**
	File Name: 2.c
	Author: zhy
	Created Time: 2017/02/28 - 14:43:20
*/
#include <stdio.h>
extern void hereis1();
extern void hereis3();
extern void hereis4();
int main(int argc, char *argv[])
{
	hereis1();
	hereis3();
	hereis4();
	return 0;
}
