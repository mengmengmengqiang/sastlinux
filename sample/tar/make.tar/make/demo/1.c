/**
	File Name: 1.c
	Author: zhy
	Created Time: 2017/02/28 - 14:42:54
*/
#include <stdio.h>
void hereis1() {
	printf("here is 11111\n");
}
