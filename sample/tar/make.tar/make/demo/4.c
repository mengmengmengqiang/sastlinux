/**
	File Name: 4.c
	Author: zhy
	Created Time: 2017/02/28 - 14:53:55
*/
#include <stdio.h>
void hereis4() {
	printf("here is 4\n");
}
