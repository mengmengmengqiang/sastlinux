/**
	File Name: 2.c
	Author: zhy
	Created Time: 2017/02/28 - 14:43:20
*/
#include <stdio.h>
extern void hereis1();
int main(int argc, char *argv[])
{
	hereis1();
	return 0;
}
