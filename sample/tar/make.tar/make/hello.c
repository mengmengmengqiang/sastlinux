/**
	File Name: hello.c
	Author: zhy
	Created Time: 2017/02/28 - 14:30:30
*/
#include <stdio.h>
#define SIZE 1024
int main(int argc, char *argv[])
{
	printf("hello,world\n");
	printf("size = %d\n", SIZE);
	return 0;
}
